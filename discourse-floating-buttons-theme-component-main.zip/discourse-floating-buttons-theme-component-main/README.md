# Discourse New Topic button theme component

A simple theme to add a "New Topic" button on every page. 

More information: https://meta.discourse.org/t/new-topic-button-on-all-pages-theme-component/84551
